For Running "runsim_sim" enter the following in the command line: 

./runsim_sim DIR CFG

where DIR is the name of the directory inside "./configs" where the configuration file is located,
and CFG is the name of the configuration file without".txt"


----------------------------------------

For running "runsim_profile" simply create a directory named "profile" inside "./configs" and execute "./runsim_profile" from the command line. 


**If you are familiar with linx scripts, you can easily alter the provided scripts as you wish. But make sure to sustain the correct order of the arguments passed to the simulator and keep a copy of the origianl scripts. 



